"use strict";
const stockSW = "./sw.js";

/**
 * Global util
 * Used in 404.html and index.html
 */
async function registerSW() {
	if (!navigator.serviceWorker) {
		// The hardcoded localhost/127.0.0.1 allowlist that used to live here
		// has been removed: browsers already treat private/LAN addresses
		// (10.x, 172.16-31.x, 192.168.x, etc.) as a secure-enough context for
		// service workers over plain http://, so that allowlist was blocking
		// legitimate single-port / LAN / port-forwarded setups before even
		// attempting registration. Let the browser's own secure-context rule
		// decide instead - if it genuinely can't register one (a public
		// hostname over plain http://, with no private/localhost exception),
		// `navigator.serviceWorker` simply won't exist and we land here.
		throw new Error(
			"Your browser doesn't support service workers here. This usually " +
				"means the page isn't loaded over https:// (or a private/local " +
				"address), which service workers require."
		);
	}

	// Register with an explicit root scope. Leaving this implicit can
	// resolve inconsistently when the page is reached via a bare IP or a
	// domain pointed at by a single A record (no CNAME) on a forwarded
	// port - an inconsistent scope is one of the ways a proxied site ends
	// up rendering as a blank "?" index instead of the real page.
	const registration = await navigator.serviceWorker.register(stockSW, {
		scope: "/",
	});

	// Proactively ask the browser to check for a newer sw.js every time this
	// runs. Without this, a browser that already has an older worker
	// registered (e.g. from before a deploy) can keep running that worker
	// until its own, much lazier update check happens to fire - this makes
	// sure it's checked right away instead.
	try {
		await registration.update();
	} catch (err) {
		// Non-fatal: the existing registration (if any) still works.
	}

	return registration;
}
