/**
 * Ghost frontend-node configuration.
 * Points at the shared Ghost backend. No trailing slash.
 */
window.__GHOST_CONFIG = {
	backendOrigin: "https://howtocookchicken.duckdns.org:24455",
	siteTitle: "Ghost",
};
