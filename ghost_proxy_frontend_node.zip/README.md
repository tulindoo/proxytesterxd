# Ghost frontend node

Static Ghost UI. Host this folder on any HTTPS site. Proxy traffic goes to:

**https://howtocookchicken.duckdns.org:24455**

(`config.js` + `sw-config.js` are already set to that backend.)

## Deploy (any OS, including Windows)

1. Unzip this archive.
2. Upload **all files and folders** to your static host web root (Netlify,
   Cloudflare Pages, IIS, Nginx, Caddy, GitHub Pages, etc.).  
   Important: keep the `baremux/` folder (it contains `worker.js`). SharedWorkers
   must be same-origin; Chromebooks and strict browsers reject a cross-origin
   worker URL from the backend.
3. Site **must be HTTPS** (service workers need a secure context).
4. On the backend (howtocookchicken…), CORS already defaults to allow **any**
   frontend origin (`GHOST_NODE_ORIGINS=*`). No extra env var required unless
   you want to restrict it later.
5. After upload you **must** clear the old code. On a Chromebook (DevTools
   often blocked) the reliable way is:
   - Open the site → padlock / site info → Cookies and site data → Clear
     data for this site.
   - Or close every tab for the site and reopen it.
   - Confirm the local worker is present: open
     `https://YOUR-SITE/baremux/worker.js` in the address bar — you should
     see JavaScript. If that 404s, the `baremux/` folder was not uploaded.
   If the error still mentions `howtocookchicken.duckdns.org` or
   `packed.local`, an old `index.js` or an old `localStorage` value is
   still active.

## Chromebook / origin 'null' SharedWorker fix

This build:

1. Loads `baremux/worker.js` via `fetch` → `Blob` → tries `SharedWorker(blob:)`.
2. If SharedWorker is still blocked (origin `"null"` / `packed.local`), falls
   back to a **dedicated Worker** + MessageChannel bridge.
3. `worker.js` itself supports both `onconnect` (SharedWorker) and dedicated
   mode (`l(self)`).

That should clear:

`SecurityError: Failed to construct 'SharedWorker': Script at
'http://packed.local/baremux/worker.js' cannot be accessed from origin
'null'.`

Proxy data still goes over WebSocket (Wisp) to the backend as before.

After deploying, clear site data again. In the console you should see either
`[ghost] bare-mux via SharedWorker` or
`[ghost] bare-mux via dedicated Worker (Chromebook fallback)`.

## Windows backend notes

If the main Ghost server runs on Windows:

```bat
set GHOST_NODE_ORIGINS=*
node src\index.js
```

Or in PowerShell:

```powershell
$env:GHOST_NODE_ORIGINS="*"
node src\index.js
```

Port **24455** must be open and the cert must cover `howtocookchicken.duckdns.org`.

## Changing the backend later

Edit both files to the same origin (no trailing slash):

- `config.js` → `backendOrigin`
- `sw-config.js` → `self.__GHOST_BACKEND`

Then hard-refresh or unregister the old service worker on the node site.
