/**
 * Must match config.js backendOrigin (service workers cannot read window).
 * No trailing slash.
 */
self.__GHOST_BACKEND = "https://howtocookchicken.duckdns.org:24455";
