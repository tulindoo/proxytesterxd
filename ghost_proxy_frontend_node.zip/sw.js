/* global self, importScripts, $scramjetLoadWorker */

// Load backend origin override first (empty string = same origin as this SW).
try {
	importScripts("./sw-config.js");
} catch (err) {
	// sw-config.js missing – treat as same-origin.
	self.__GHOST_BACKEND = self.__GHOST_BACKEND || "";
}

const backend = String(self.__GHOST_BACKEND || "").replace(/\/$/, "");
const scramBase = backend ? backend + "/scram" : "/scram";

importScripts(scramBase + "/scramjet.all.js");

const { ScramjetServiceWorker } = $scramjetLoadWorker();
const scramjet = new ScramjetServiceWorker();

// Activate immediately and claim clients so deploys don't leave stale workers.
self.addEventListener("install", () => {
	self.skipWaiting();
});

self.addEventListener("activate", (event) => {
	event.waitUntil(self.clients.claim());
});

async function handleRequest(event) {
	await scramjet.loadConfig();
	if (scramjet.route(event)) {
		return scramjet.fetch(event);
	}
	return fetch(event.request);
}

self.addEventListener("fetch", (event) => {
	event.respondWith(handleRequest(event));
});
