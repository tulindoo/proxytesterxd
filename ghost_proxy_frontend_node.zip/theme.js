"use strict";
/**
 * Applies the saved/system theme before first paint so there is no flash
 * of the wrong theme. Loaded synchronously (not `defer`) in <head>.
 */
(function () {
	const STORAGE_KEY = "sj-theme";

	function systemPrefersLight() {
		try {
			return (
				window.matchMedia &&
				window.matchMedia("(prefers-color-scheme: light)").matches
			);
		} catch (err) {
			return false;
		}
	}

	function systemCanDetect() {
		try {
			return (
				window.matchMedia &&
				(window.matchMedia("(prefers-color-scheme: light)").matches ||
					window.matchMedia("(prefers-color-scheme: dark)").matches)
			);
		} catch (err) {
			return false;
		}
	}

	function getStoredTheme() {
		try {
			return localStorage.getItem(STORAGE_KEY);
		} catch (err) {
			return null;
		}
	}

	function resolveTheme() {
		const stored = getStoredTheme();
		if (stored === "light" || stored === "dark") return stored;
		// No explicit user choice: follow the system theme. If the system
		// theme can't be detected at all, default to dark.
		if (!systemCanDetect()) return "dark";
		return systemPrefersLight() ? "light" : "dark";
	}

	window.__sjTheme = {
		STORAGE_KEY,
		resolveTheme,
		getStoredTheme,
		systemCanDetect,
	};

	document.documentElement.setAttribute("data-theme", resolveTheme());
})();
