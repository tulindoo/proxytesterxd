@echo off
set PORT=24455
set GHOST_NODE_ORIGINS=*
cd /d "%USERPROFILE%\Documents\Scramjet-App"
pnpm start
Ghost.bat