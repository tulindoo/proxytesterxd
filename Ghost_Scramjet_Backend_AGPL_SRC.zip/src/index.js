import { createServer as createHttpServer } from "node:http";
import { createServer as createHttpsServer } from "node:https";
import { createServer as createNetServer } from "node:net";
import { existsSync, readFileSync, watch } from "node:fs";
import { join } from "node:path";
import { fileURLToPath } from "url";
import { hostname } from "node:os";
import { server as wisp, logging } from "@mercuryworkshop/wisp-js/server";
import Fastify from "fastify";
import fastifyStatic from "@fastify/static";

import { scramjetPath } from "@mercuryworkshop/scramjet/path";
import { libcurlPath } from "@mercuryworkshop/libcurl-transport";
import { baremuxPath } from "@mercuryworkshop/bare-mux/node";

import { loadDomains, pickDefaultDomain } from "./domains.js";
import {
	checkRequest,
	recordNotFound,
	isBlacklisted,
	rateLimitConfig,
} from "./ratelimit.js";

const publicPath = fileURLToPath(new URL("../public/", import.meta.url));
const certsPath = fileURLToPath(new URL("../certs/", import.meta.url));

// ---------------------------------------------------------------------------
// Frontend nodes (multi-host UI)
//
// Remote static frontends can be hosted on other HTTPS origins and still use
// this process as the shared proxy backend (/wisp/, /scram/, /baremux/,
// /libcurl/). Set GHOST_NODE_ORIGINS to a comma-separated list of allowed
// node origins (e.g. "https://node1.example.com,https://node2.example.com")
// or "*" to reflect any Origin. Empty = same-origin only for CORS purposes
// (classic single-host mode still works either way).
// ---------------------------------------------------------------------------
const NODE_ORIGINS_RAW = (process.env.GHOST_NODE_ORIGINS || "*").trim();
const NODE_ORIGINS = NODE_ORIGINS_RAW
	? NODE_ORIGINS_RAW.split(",").map((s) => s.trim().replace(/\/$/, "")).filter(Boolean)
	: [];
const NODE_ORIGINS_ALLOW_ALL = NODE_ORIGINS.includes("*");

function corsOriginFor(req) {
	const origin = req.headers.origin;
	if (!origin) return null;
	if (NODE_ORIGINS_ALLOW_ALL) return origin;
	if (NODE_ORIGINS.length === 0) return null;
	const normalized = origin.replace(/\/$/, "");
	if (NODE_ORIGINS.includes(normalized)) return origin;
	return null;
}

function applyNodeCorsHeaders(req, res) {
	const allowed = corsOriginFor(req);
	if (!allowed) return;
	res.setHeader("Access-Control-Allow-Origin", allowed);
	res.setHeader("Access-Control-Allow-Credentials", "true");
	res.setHeader("Access-Control-Allow-Methods", "GET,HEAD,POST,OPTIONS");
	res.setHeader(
		"Access-Control-Allow-Headers",
		req.headers["access-control-request-headers"] || "Content-Type, Range"
	);
	res.setHeader("Vary", "Origin");
	// Let frontend nodes load scram/baremux/libcurl under COEP if they opt in.
	res.setHeader("Cross-Origin-Resource-Policy", "cross-origin");
}

// ---------------------------------------------------------------------------
// Optional HTTPS on the SAME port as plain HTTP, now with multi-domain (SNI)
// support.
//
// Ghost proxies sites through a service worker, and browsers only allow
// service workers on https:// pages or on localhost - a plain http:// page
// on a LAN IP or public domain is not a "secure context", so the worker (and
// bare-mux) simply do not exist there. That is what used to kill the whole
// page on a forwarded http:// port. There is no way to work around that
// from server code, so the fix is to be reachable over HTTPS on the one
// forwarded port.
//
// Certificates now live under certs/<domain>/cert.pem + key.pem, one folder
// per domain (up to 5, see certs/domains.json), each tagged with a dm.link
// file so a folder can always be matched back to its domains.json entry.
// Domains can be enabled/disabled independently. A legacy single
// certs/cert.pem + certs/key.pem pair (the old single-domain layout) is
// migrated into its own folder automatically on startup.
//
// The legacy SSL_CERT / SSL_KEY env vars still work too, and are treated as
// one more (highest priority) domain entry so existing setups keep working
// unmodified.
// ---------------------------------------------------------------------------

function loadEnvOverrideDomain() {
	const certFile = process.env.SSL_CERT;
	const keyFile = process.env.SSL_KEY;
	if (!certFile && !keyFile) return null;
	if (!existsSync(certFile) || !existsSync(keyFile)) {
		console.warn(
			`HTTPS env override disabled: could not find the certificate (${certFile}) or key (${keyFile}).`
		);
		return null;
	}
	try {
		return {
			cert: readFileSync(certFile),
			key: readFileSync(keyFile),
			passphrase: process.env.SSL_PASSPHRASE || undefined,
		};
	} catch (err) {
		console.warn(`HTTPS env override disabled: could not read the certificate/key: ${err}`);
		return null;
	}
}

/**
 * Builds the current multi-domain TLS state: a Map of domain -> secure
 * context (for SNICallback) plus a single set of default tlsOptions (for
 * clients that connect without SNI, or the legacy single-domain case).
 */
function buildTlsState() {
	const envOverride = loadEnvOverrideDomain();
	const { contexts } = loadDomains(certsPath);

	if (envOverride) {
		// SSL_CERT/SSL_KEY wins as the default; multi-domain certs (if any)
		// are still loaded for SNI so this stays a strict superset of the
		// old single-cert behavior.
		return {
			enabled: true,
			defaultOptions: envOverride,
			contexts,
		};
	}

	if (contexts.size === 0) return { enabled: false, defaultOptions: null, contexts };

	const fallback = pickDefaultDomain(contexts);
	return {
		enabled: true,
		defaultOptions: { cert: fallback.cert, key: fallback.key },
		contexts,
	};
}

let tlsState = buildTlsState();

/**
 * Hosts a browser already treats as a secure context over plain http://, so
 * there is nothing to gain by redirecting them to https://.
 * @param {string | undefined} hostHeader
 */
function isLoopbackHost(hostHeader) {
	// Without a Host header there is nothing to build a redirect from.
	if (!hostHeader) return true;
	const host = (
		hostHeader.startsWith("[")
			? hostHeader.slice(1, hostHeader.indexOf("]"))
			: hostHeader.split(":")[0]
	).toLowerCase();
	return (
		host === "localhost" ||
		host.endsWith(".localhost") ||
		host === "::1" ||
		/^127\./.test(host)
	);
}

// Wisp Configuration: Refer to the documentation at https://www.npmjs.com/package/@mercuryworkshop/wisp-js

logging.set_level(logging.NONE);
Object.assign(wisp.options, {
	allow_udp_streams: false,
	hostname_blacklist: [/example\.com/],
	dns_servers: ["1.1.1.3", "1.0.0.3"],
});

// ---------------------------------------------------------------------------
// Bot / abusive-client rate limiting.
//
// Any client IP that either sustains too high a request rate, or racks up
// too many 404 / invalid-path hits (classic scanner/bot behavior), gets
// blacklisted and 403'd for a while. Set RATE_HARD_BLOCK=true to drop the
// raw TCP connection outright for blacklisted IPs instead of answering with
// a 403 (closer to blocking their traffic entirely at the socket level).
// ---------------------------------------------------------------------------

const fastify = Fastify({
	trustProxy: true,
	serverFactory: (handler) => {
		const onRequest = (req, res) => {
			const ip = req.socket.remoteAddress;

			// Blacklisted IPs never reach the app - either a flat 403, or
			// (if RATE_HARD_BLOCK) the connection is simply dropped below
			// in the net.Server "connection" handler, before we even get
			// here for plain HTTP. This 403 covers the non-hard-block path
			// and any request that slips through on an already-open
			// keep-alive socket.
			if (isBlacklisted(ip)) {
				res.writeHead(403, { "Content-Type": "text/plain", "Cache-Control": "no-store" });
				res.end("403 Forbidden\n");
				return;
			}

			// Pass the request URL so the index path is never rate-limited
			// and suspicious paths (admin, control panel, etc.) are blocked.
			const { blocked } = checkRequest(ip, req.url);
			if (blocked) {
				res.writeHead(403, { "Content-Type": "text/plain", "Cache-Control": "no-store" });
				res.end("403 Forbidden\n");
				return;
			}

			// A plain-http request for a real (non-loopback) address can never
			// run the service worker, so send it to https:// on this same port.
			if (
				tlsState.enabled &&
				!req.socket.encrypted &&
				!isLoopbackHost(req.headers.host)
			) {
				res.writeHead(307, {
					Location: `https://${req.headers.host}${req.url}`,
					"Cache-Control": "no-store",
				});
				res.end();
				return;
			}

			// CORS / CORP for frontend nodes that load /scram /baremux /libcurl
			// and open the /wisp/ WebSocket from a different origin.
			applyNodeCorsHeaders(req, res);

			// Preflight from a node origin.
			if (req.method === "OPTIONS" && corsOriginFor(req)) {
				res.writeHead(204, { "Cache-Control": "no-store" });
				res.end();
				return;
			}

			// COOP/COEP help the same-origin app isolate itself; skip them for
			// cross-origin asset responses so remote nodes can actually load
			// the shared client libraries.
			const isSharedAsset =
				req.url.startsWith("/scram/") ||
				req.url.startsWith("/baremux/") ||
				req.url.startsWith("/libcurl/");
			if (!isSharedAsset && !corsOriginFor(req)) {
				res.setHeader("Cross-Origin-Opener-Policy", "same-origin");
				res.setHeader("Cross-Origin-Embedder-Policy", "require-corp");
			}
			// Never redirect/rewrite based on our own bind address; always
			// respect whatever Host the client actually connected to so a
			// single port forwarded straight through (bare IP or domain,
			// no CNAME) keeps working.
			res.setHeader("Vary", "Host, Origin");

			res.on("finish", () => {
				if (res.statusCode === 404) recordNotFound(ip);
			});

			handler(req, res);
		};

		const onUpgrade = (req, socket, head) => {
			const ip = socket.remoteAddress;
			if (isBlacklisted(ip) || checkRequest(ip, req.url).blocked) {
				socket.end();
				return;
			}
			// Match the wisp endpoint regardless of any trailing query
			// string a proxy/port-forward may append.
			const path = req.url.split("?")[0];
			if (path.endsWith("/wisp/")) wisp.routeRequest(req, socket, head);
			else socket.end();
		};

		const httpServer = createHttpServer()
			.on("request", onRequest)
			.on("upgrade", onUpgrade);

		if (!tlsState.enabled) return wrapWithHardBlock(httpServer, null);

		let httpsServer;
		try {
			httpsServer = createHttpsServer({
				...tlsState.defaultOptions,
				SNICallback: (serverName, callback) => {
					const match = tlsState.contexts.get(serverName);
					if (match) return callback(null, match.secureContext);
					// Unknown SNI name: fall back to the default cert rather
					// than failing the handshake outright.
					callback(null, null);
				},
			})
				.on("request", onRequest)
				.on("upgrade", onUpgrade);
		} catch (err) {
			console.warn(`HTTPS disabled: invalid certificate/key: ${err}`);
			tlsState.enabled = false;
			return wrapWithHardBlock(httpServer, null);
		}

		// One listening socket, two protocols: peek at the first byte of every
		// connection (0x16 = TLS handshake, anything else = HTTP) and hand the
		// socket to whichever server speaks that protocol.
		const combined = createNetServer((socket) => {
			if (rateLimitConfig.HARD_BLOCK && isBlacklisted(socket.remoteAddress)) {
				socket.destroy();
				return;
			}
			socket.on("error", () => socket.destroy());
			socket.setTimeout(15000, () => socket.destroy());
			socket.once("data", (chunk) => {
				socket.setTimeout(0);
				socket.pause();
				socket.unshift(chunk);
				(chunk[0] === 0x16 ? httpsServer : httpServer).emit(
					"connection",
					socket
				);
				process.nextTick(() => socket.resume());
			});
		});
		return combined;
	},
});

/** Hard-block variant of the plain-HTTP-only path (no TLS configured). */
function wrapWithHardBlock(httpServer, _unused) {
	if (!rateLimitConfig.HARD_BLOCK) return httpServer;
	return createNetServer((socket) => {
		if (isBlacklisted(socket.remoteAddress)) {
			socket.destroy();
			return;
		}
		httpServer.emit("connection", socket);
	});
}

fastify.register(fastifyStatic, {
	root: publicPath,
	decorateReply: true,
});

fastify.register(fastifyStatic, {
	root: scramjetPath,
	prefix: "/scram/",
	decorateReply: false,
});

fastify.register(fastifyStatic, {
	root: libcurlPath,
	prefix: "/libcurl/",
	decorateReply: false,
});

fastify.register(fastifyStatic, {
	root: baremuxPath,
	prefix: "/baremux/",
	decorateReply: false,
});

fastify.setNotFoundHandler((res, reply) => {
	// Count this toward the IP's "invalid index / 404" rate limit too - the
	// res.on("finish") hook above also catches this via statusCode, but
	// recording it here as well costs nothing and covers any path that
	// doesn't flow through that handler.
	recordNotFound(res.ip);
	return reply.code(404).type("text/html").sendFile("404.html");
});

fastify.server.on("listening", () => {
	const address = fastify.server.address();

	// by default we are listening on 0.0.0.0 (every interface)
	// we just need to list a few
	console.log("Listening on:");
	console.log(`\thttp://localhost:${address.port}`);
	console.log(`\thttp://${hostname()}:${address.port}`);
	console.log(
		`\thttp://${
			address.family === "IPv6" ? `[${address.address}]` : address.address
		}:${address.port}`
	);

	if (tlsState.enabled) {
		console.log("HTTPS is enabled on this same port:");
		console.log(`\thttps://${hostname()}:${address.port}`);
		console.log(
			"\tplain http:// to any address other than localhost is redirected to https://"
		);
		if (tlsState.contexts.size > 0) {
			console.log(
				`\tactive HTTPS domains: ${[...tlsState.contexts.keys()].join(", ")}`
			);
		}
	} else {
		console.log(
			"HTTPS is off. Browsers only run Ghost's service worker on https:// or http://localhost -"
		);
		console.log(
			"\tfor a LAN/public address, set SSL_CERT + SSL_KEY, or add certs/<domain>/cert.pem + key.pem."
		);
	}

	console.log(
		`Rate limiting: ${rateLimitConfig.MAX_REQUESTS_PER_WINDOW} req / ${rateLimitConfig.WINDOW_MS / 1000}s, ` +
			`${rateLimitConfig.MAX_NOT_FOUND_PER_WINDOW} 404s / ${rateLimitConfig.WINDOW_MS / 1000}s, ` +
			`block duration ${rateLimitConfig.BLOCK_DURATION_MS / 60_000}min` +
			`${rateLimitConfig.HARD_BLOCK ? " (hard socket block)" : ""}.`
	);

	if (NODE_ORIGINS_ALLOW_ALL) {
		console.log("Frontend nodes: CORS open (GHOST_NODE_ORIGINS=*)");
	} else if (NODE_ORIGINS.length > 0) {
		console.log(`Frontend nodes allowed: ${NODE_ORIGINS.join(", ")}`);
	} else {
		console.log(
			"Frontend nodes: none configured (set GHOST_NODE_ORIGINS to enable remote UIs)."
		);
	}
});

// Watch certs/ so a domain added/changed by the renew bot (ghost_cert_renew.py
// reg / regdel, or a routine renewal) is picked up without a manual restart
// request - in practice the renew bot also asks us to restart outright after
// a change (see its kill/relaunch logic), but this keeps things correct even
// if the server is left running on its own.
try {
	watch(certsPath, { persistent: false }, () => {
		// Debounce: certs/ gets several events per migration/renewal.
		clearTimeout(watchDebounce);
		watchDebounce = setTimeout(() => {
			console.log("Detected a change under certs/ - reloading domain certificates...");
			tlsState = buildTlsState();
		}, 500);
	});
} catch {
	// Non-fatal if the platform's fs.watch can't watch this path.
}
let watchDebounce;

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

function shutdown() {
	console.log("SIGTERM signal received: closing HTTP server");
	fastify.close();
	process.exit(0);
}

let port = parseInt(process.env.PORT || "");

if (isNaN(port)) port = 8080;

fastify.listen({
	port: port,
	host: "0.0.0.0",
});
