import { createSecureContext } from "node:tls";
import {
	existsSync,
	readFileSync,
	writeFileSync,
	mkdirSync,
	renameSync,
	readdirSync,
	rmSync,
} from "node:fs";
import { join } from "node:path";
import { X509Certificate } from "node:crypto";

// ---------------------------------------------------------------------------
// Multi-domain HTTPS certificate management.
//
// Layout (all under certsPath, i.e. the project's certs/ folder):
//
//   certs/
//     domains.json              <- root config, up to MAX_DOMAINS entries
//     <domain-name>/
//       cert.pem
//       key.pem
//       dm.link                 <- just the domain's "id" (matches domains.json)
//
// domains.json looks like:
//   {
//     "domains": [
//       { "id": "howtocookchicken.duckdns.org", "enabled": true },
//       { "id": "example2.duckdns.org", "enabled": false }
//     ]
//   }
//
// Any domain folder's dm.link must contain exactly the "id" of the entry in
// domains.json it belongs to - that's how a folder is matched back to its
// config row. This module also migrates a legacy top-level certs/cert.pem +
// certs/key.pem pair (the old single-domain layout) into its own domain
// folder automatically, naming the folder after the certificate's CN
// wherever that can be read.
// ---------------------------------------------------------------------------

export const MAX_DOMAINS = 5;

function domainsJsonPath(certsPath) {
	return join(certsPath, "domains.json");
}

function safeFolderName(name) {
	// Domain names are already filesystem-safe in practice, but be defensive.
	return String(name).trim().toLowerCase().replace(/[^a-z0-9.\-_]/g, "_");
}

function readCn(certPath) {
	try {
		const cert = new X509Certificate(readFileSync(certPath));
		const subject = cert.subject || "";
		const match = /CN=([^\n,]+)/.exec(subject);
		if (match) return match[1].trim();
		// Fall back to the first SAN DNS entry if there's no usable CN.
		const san = cert.subjectAltName || "";
		const sanMatch = /DNS:([^,]+)/.exec(san);
		if (sanMatch) return sanMatch[1].trim();
	} catch {
		// unreadable / unparsable certificate - caller decides what to do
	}
	return null;
}

export function loadDomainsConfig(certsPath) {
	const file = domainsJsonPath(certsPath);
	if (!existsSync(file)) return { domains: [] };
	try {
		const parsed = JSON.parse(readFileSync(file, "utf-8"));
		if (!Array.isArray(parsed.domains)) return { domains: [] };
		return parsed;
	} catch (err) {
		console.warn(`domains.json is unreadable/invalid (${err}); ignoring it.`);
		return { domains: [] };
	}
}

export function saveDomainsConfig(certsPath, config) {
	mkdirSync(certsPath, { recursive: true });
	writeFileSync(domainsJsonPath(certsPath), JSON.stringify(config, null, 2));
}

/**
 * Moves a legacy certs/cert.pem + certs/key.pem pair into its own
 * certs/<domain>/ subfolder, writes its dm.link, and adds/updates its entry
 * in domains.json. No-op if there's nothing at the legacy path.
 */
function migrateLegacyCert(certsPath, config) {
	const legacyCert = join(certsPath, "cert.pem");
	const legacyKey = join(certsPath, "key.pem");
	if (!existsSync(legacyCert) || !existsSync(legacyKey)) return config;

	let id = readCn(legacyCert) || "legacy-domain";
	id = safeFolderName(id);

	// Avoid clobbering an existing properly-migrated domain folder of the
	// same name; if one exists already, suffix this one.
	let folderName = id;
	let suffix = 2;
	while (
		existsSync(join(certsPath, folderName)) &&
		!config.domains.some((d) => d.id === folderName)
	) {
		folderName = `${id}-${suffix++}`;
	}

	const destDir = join(certsPath, folderName);
	mkdirSync(destDir, { recursive: true });
	renameSync(legacyCert, join(destDir, "cert.pem"));
	renameSync(legacyKey, join(destDir, "key.pem"));
	writeFileSync(join(destDir, "dm.link"), folderName);

	if (!config.domains.some((d) => d.id === folderName)) {
		config.domains.push({ id: folderName, enabled: true });
	}

	console.log(
		`Migrated legacy certs/cert.pem + key.pem into certs/${folderName}/ (detected domain: ${id}).`
	);
	return config;
}

/**
 * Scans certs/ for subfolders carrying a dm.link + cert.pem/key.pem that
 * aren't yet listed in domains.json (e.g. dropped in manually, or added by
 * the renew bot while the server was down) and registers them.
 */
function discoverUntrackedFolders(certsPath, config) {
	if (!existsSync(certsPath)) return config;
	const known = new Set(config.domains.map((d) => d.id));
	for (const entry of readdirSync(certsPath, { withFileTypes: true })) {
		if (!entry.isDirectory()) continue;
		const dir = join(certsPath, entry.name);
		const linkFile = join(dir, "dm.link");
		const certFile = join(dir, "cert.pem");
		const keyFile = join(dir, "key.pem");
		if (!existsSync(linkFile) || !existsSync(certFile) || !existsSync(keyFile))
			continue;
		let id;
		try {
			id = readFileSync(linkFile, "utf-8").trim();
		} catch {
			continue;
		}
		if (!id || known.has(id)) continue;
		config.domains.push({ id, enabled: true });
		known.add(id);
		console.log(`Discovered untracked domain folder certs/${entry.name}/ (id: ${id}).`);
	}
	return config;
}

/**
 * Loads (and if needed migrates/discovers) the full multi-domain cert setup.
 * Returns { config, contexts } where contexts is a Map<domainId, {cert,key,secureContext}>
 * for every *enabled* domain whose cert/key could actually be read, keyed
 * by the domain id (which should match the hostname used for SNI lookups).
 */
export function loadDomains(certsPath) {
	mkdirSync(certsPath, { recursive: true });
	let config = loadDomainsConfig(certsPath);
	config = migrateLegacyCert(certsPath, config);
	config = discoverUntrackedFolders(certsPath, config);
	saveDomainsConfig(certsPath, config);

	const contexts = new Map();
	for (const entry of config.domains) {
		if (!entry.enabled) continue;
		const dir = join(certsPath, safeFolderName(entry.id));
		const certFile = join(dir, "cert.pem");
		const keyFile = join(dir, "key.pem");
		if (!existsSync(certFile) || !existsSync(keyFile)) {
			console.warn(
				`Domain "${entry.id}" is enabled in domains.json but certs/${entry.id}/cert.pem or key.pem is missing - skipping.`
			);
			continue;
		}
		try {
			const cert = readFileSync(certFile);
			const key = readFileSync(keyFile);
			const secureContext = createSecureContext({ cert, key });
			contexts.set(entry.id, { cert, key, secureContext });
		} catch (err) {
			console.warn(`Could not load certificate for "${entry.id}": ${err}`);
		}
	}

	return { config, contexts };
}

/** Picks a default/fallback domain's TLS options for non-SNI clients. */
export function pickDefaultDomain(contexts) {
	const first = contexts.values().next();
	return first.done ? null : first.value;
}

export function enableDomain(certsPath, id, enabled) {
	const config = loadDomainsConfig(certsPath);
	const entry = config.domains.find((d) => d.id === id);
	if (!entry) return false;
	entry.enabled = enabled;
	saveDomainsConfig(certsPath, config);
	return true;
}

export function removeDomain(certsPath, id) {
	const config = loadDomainsConfig(certsPath);
	const idx = config.domains.findIndex((d) => d.id === id);
	if (idx === -1) return false;
	config.domains.splice(idx, 1);
	saveDomainsConfig(certsPath, config);
	const dir = join(certsPath, safeFolderName(id));
	if (existsSync(dir)) rmSync(dir, { recursive: true, force: true });
	return true;
}

export { safeFolderName };
