// ---------------------------------------------------------------------------
// Lightweight in-memory rate limiting + blacklisting.
//
// Two things are tracked per client IP, in sliding windows:
//   1. overall request rate  - too many requests in too short a time
//   2. "probing" behavior    - too many 404s / invalid-path responses
//
// Either one tripping blacklists the IP. A blacklisted IP gets a 403 for
// BLOCK_DURATION_MS, after which it's given a fresh chance. Set
// HARD_BLOCK=true to drop the raw socket for blacklisted IPs the moment a
// new connection arrives, instead of letting the request reach Fastify at
// all (closer to "block its network traffic entirely").
//
// All thresholds are deliberately simple/static - no external dependency,
// no persistence. This is meant to blunt casual scanning/abuse, not to
// replace a real WAF.
// ---------------------------------------------------------------------------

const WINDOW_MS = parseInt(process.env.RATE_WINDOW_MS || "", 10) || 10_000; // 10s window
const MAX_REQUESTS_PER_WINDOW =
	parseInt(process.env.RATE_MAX_REQUESTS || "", 10) || 120; // ~12 req/s sustained
const MAX_NOT_FOUND_PER_WINDOW =
	parseInt(process.env.RATE_MAX_404S || "", 10) || 20; // 404/invalid-path probing
const BLOCK_DURATION_MS =
	parseInt(process.env.RATE_BLOCK_DURATION_MS || "", 10) || 15 * 60_000; // 15 min
const HARD_BLOCK = /^(1|true|yes)$/i.test(process.env.RATE_HARD_BLOCK || "");

// ip -> { requestTimestamps: number[], notFoundTimestamps: number[], blockedUntil: number|null }
const buckets = new Map();

function getBucket(ip) {
	let bucket = buckets.get(ip);
	if (!bucket) {
		bucket = { requestTimestamps: [], notFoundTimestamps: [], blockedUntil: null };
		buckets.set(ip, bucket);
	}
	return bucket;
}

function prune(timestamps, now) {
	while (timestamps.length && now - timestamps[0] > WINDOW_MS) timestamps.shift();
}

/** Real client IP, honoring trustProxy (fastify already resolves req.ip, but
 *  this module also gets used from the raw socket layer before fastify sees
 *  the request, so accept either a Fastify request or a raw IP string). */
function resolveIp(reqOrIp) {
	if (typeof reqOrIp === "string") return reqOrIp;
	return reqOrIp.ip || reqOrIp.socket?.remoteAddress || "unknown";
}

/**
 * Paths that must never be rate-limited (the main index / home page).
 * Visits to the homepage itself are exempt unless a future change says otherwise.
 */
function isIndexPath(urlPath) {
	if (!urlPath) return true;
	const p = urlPath.split("?")[0].split("#")[0];
	return p === "/" || p === "/index.html" || p === "/index.htm" || p === "";
}

/**
 * Suspicious path keywords typical of scanners / control-panel probes.
 * Matching any of these on a non-index request causes an immediate blacklist.
 */
const SUSPICIOUS_PATH_RE =
	/(?:^|\/)(?:admin|administrator|wp-admin|wp-login|control[\s_-]?panel|cpanel|phpmyadmin|manager|console|backend|dashboard|login\.php|xmlrpc\.php|\.env|config\.php|setup\.php)(?:\/|$|\.)/i;

/**
 * Call once per incoming request (as early as possible). Returns:
 *   { blocked: true }                      - already blacklisted, reject now
 *   { blocked: false }                     - OK to proceed
 * Also internally records the hit against the rate-limit window and may
 * blacklist the IP for future requests if it just tipped over the limit.
 *
 * The main index path is never rate-limited or keyword-blocked.
 * Pass the request path (or full URL) as the optional second argument so
 * index exemption and keyword checks can run.
 */
export function checkRequest(reqOrIp, urlPath) {
	const ip = resolveIp(reqOrIp);
	const now = Date.now();
	const bucket = getBucket(ip);

	if (bucket.blockedUntil) {
		if (now < bucket.blockedUntil) {
			return { blocked: true, ip };
		}
		// Block window elapsed - give them a clean slate.
		bucket.blockedUntil = null;
		bucket.requestTimestamps = [];
		bucket.notFoundTimestamps = [];
	}

	// Index is always allowed through (no rate accounting, no keyword ban).
	const path =
		typeof urlPath === "string"
			? urlPath
			: typeof reqOrIp === "object" && reqOrIp.url
				? reqOrIp.url
				: "";
	if (isIndexPath(path)) {
		return { blocked: false, ip, index: true };
	}

	// Immediate block for classic admin / control-panel probe paths.
	if (SUSPICIOUS_PATH_RE.test(path)) {
		blacklist(
			ip,
			`suspicious path probe: ${String(path).split("?")[0].slice(0, 120)}`
		);
		return { blocked: true, ip };
	}

	prune(bucket.requestTimestamps, now);
	bucket.requestTimestamps.push(now);

	if (bucket.requestTimestamps.length > MAX_REQUESTS_PER_WINDOW) {
		blacklist(ip, "exceeded request rate limit");
		return { blocked: true, ip };
	}

	return { blocked: false, ip };
}

/** Call after a response is known to be a 404 / invalid-index lookup. */
export function recordNotFound(reqOrIp) {
	const ip = resolveIp(reqOrIp);
	const now = Date.now();
	const bucket = getBucket(ip);
	prune(bucket.notFoundTimestamps, now);
	bucket.notFoundTimestamps.push(now);

	if (bucket.notFoundTimestamps.length > MAX_NOT_FOUND_PER_WINDOW) {
		blacklist(ip, "excessive 404 / invalid-path probing");
	}
}

export function blacklist(ip, reason) {
	const bucket = getBucket(ip);
	if (!bucket.blockedUntil) {
		console.warn(
			`[ratelimit] blacklisting ${ip} for ${Math.round(BLOCK_DURATION_MS / 1000)}s: ${reason}`
		);
	}
	bucket.blockedUntil = Date.now() + BLOCK_DURATION_MS;
}

export function isBlacklisted(reqOrIp) {
	const ip = resolveIp(reqOrIp);
	const bucket = buckets.get(ip);
	if (!bucket || !bucket.blockedUntil) return false;
	if (Date.now() >= bucket.blockedUntil) {
		bucket.blockedUntil = null;
		return false;
	}
	return true;
}

export const rateLimitConfig = {
	WINDOW_MS,
	MAX_REQUESTS_PER_WINDOW,
	MAX_NOT_FOUND_PER_WINDOW,
	BLOCK_DURATION_MS,
	HARD_BLOCK,
};

// Periodic cleanup so the Map doesn't grow forever from one-off visitors.
setInterval(
	() => {
		const now = Date.now();
		for (const [ip, bucket] of buckets) {
			const stale =
				(!bucket.blockedUntil || now >= bucket.blockedUntil) &&
				bucket.requestTimestamps.length === 0 &&
				bucket.notFoundTimestamps.length === 0;
			if (stale) buckets.delete(ip);
		}
	},
	5 * 60_000
).unref();
