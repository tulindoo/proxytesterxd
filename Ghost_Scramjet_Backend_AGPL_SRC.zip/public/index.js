"use strict";
/**
 * @type {HTMLFormElement}
 */
const form = document.getElementById("sj-form");
/**
 * @type {HTMLInputElement}
 */
const address = document.getElementById("sj-address");
/**
 * @type {HTMLInputElement}
 */
const searchEngine = document.getElementById("sj-search-engine");
/**
 * @type {HTMLSelectElement}
 */
const engineSelect = document.getElementById("sj-engine-select");
/**
 * @type {HTMLParagraphElement}
 */
const error = document.getElementById("sj-error");
/**
 * @type {HTMLPreElement}
 */
const errorCode = document.getElementById("sj-error-code");

/**
 * @type {HTMLElement}
 */
const homeView = document.getElementById("sj-home");
/**
 * @type {HTMLElement}
 */
const browseView = document.getElementById("sj-browse-view");
/**
 * @type {HTMLElement}
 */
const toast = document.getElementById("sj-toast");

/**
 * Everything below this comment is organised so that NOTHING that can fail
 * (the proxy engine, the service worker, bare-mux) runs at the top level.
 * Those pieces need a "secure context" (https:// or localhost) and simply do
 * not exist on a plain http:// LAN/public address. Previously they were
 * constructed right here, so on such an address the very first one threw,
 * the script stopped, and none of the listeners further down (search form,
 * quick links, navbar, theme toggle...) were ever attached - which is why
 * the page looked dead and the browser fell back to a native form submit
 * (the "?" in the address bar). Now they are created lazily inside
 * initProxy(), and any failure is shown on screen instead.
 */

/* ----------------------------------------------------------------- *
 * Error reporting
 * ----------------------------------------------------------------- */

let toastTimer = null;

function clearError() {
	error.textContent = "";
	errorCode.textContent = "";
}

/**
 * Shows a problem where the person will actually see it: in the error area
 * on the home screen, or as a toast while a proxied page is on screen.
 * @param {string} headline
 * @param {string} [detail]
 */
function showProblem(headline, detail) {
	error.textContent = headline;
	errorCode.textContent = detail || "";

	if (!homeView.hidden) return;
	toast.textContent = headline;
	toast.hidden = false;
	clearTimeout(toastTimer);
	toastTimer = setTimeout(() => {
		toast.hidden = true;
	}, 6000);
}

/**
 * @param {unknown} err
 * @param {string} fallbackHeadline
 */
function reportError(err, fallbackHeadline) {
	console.error(err);
	if (err && typeof err === "object" && "headline" in err) {
		showProblem(String(err.headline), String(err.detail || ""));
		return;
	}
	showProblem(fallbackHeadline, String(err));
}

/* ----------------------------------------------------------------- *
 * Proxy engine (service worker + scramjet + bare-mux), created lazily
 * ----------------------------------------------------------------- */

/** @type {any} */
let scramjet = null;
/** @type {any} */
let connection = null;
/** @type {Promise<void> | null} */
let proxyReady = null;
/** @type {Worker | null} dedicated bare-mux worker when SharedWorker is blocked */
let baremuxDedicatedWorker = null;
/** true when we fell back to dedicated Worker (needs setRemoteTransport + getPort) */
let baremuxUseRemoteTransport = false;

/**
 * Origin of the Ghost backend that owns /wisp/, /scram/, /baremux/, /libcurl/.
 * Empty config => same origin as this page (classic single-host deploy).
 * Frontend nodes set window.__GHOST_CONFIG.backendOrigin to the remote backend.
 * @returns {string} origin with no trailing slash
 */
function getBackendOrigin() {
	try {
		const cfg = window.__GHOST_CONFIG || {};
		let raw = (cfg.backendOrigin || "").trim().replace(/\/$/, "");
		// Guard against shipping the template placeholder by accident.
		if (/YOUR-BACKEND/i.test(raw)) {
			console.error(
				"[ghost] config.js still contains YOUR-BACKEND-ORIGIN-HERE. " +
					"Edit config.js and sw-config.js to your real backend origin."
			);
			raw = "";
		}
		if (raw) return raw;
	} catch (err) {
		/* ignore */
	}
	return location.origin;
}

/** @returns {boolean} true when this UI is on a different origin than the backend */
function isRemoteNode() {
	return getBackendOrigin() !== location.origin;
}

/**
 * Describes why the proxy can't run on this page, or null if it can.
 * @returns {{ headline: string, detail: string } | null}
 */
function getContextProblem() {
	if (window.isSecureContext && navigator.serviceWorker) return null;

	if (location.protocol === "https:") {
		return {
			headline: "Your browser blocked service workers on this page.",
			detail:
				"Ghost needs a service worker to proxy sites. This usually means " +
				"the HTTPS certificate isn't trusted by this browser (self-signed " +
				"certificates don't work), or service workers are disabled " +
				"(some private/incognito modes).",
		};
	}

	return {
		headline: "Browsing is unavailable on this address (plain http://).",
		detail:
			"Ghost needs a service worker to proxy sites, and browsers only allow " +
			"service workers on https:// pages or on localhost - not on http://" +
			location.host +
			".\n\n" +
			"Fix: serve Ghost over HTTPS. Put your certificate and key at " +
			"certs/cert.pem and certs/key.pem (or set SSL_CERT and SSL_KEY) and " +
			"restart - the same port then serves both http:// and https:// and " +
			"redirects http:// to https:// automatically. Or open it through " +
			"http://localhost on the machine running it.",
	};
}

/**
 * Creates the scramjet controller and bare-mux connection (once).
 * Rejects with a `{ headline, detail }` error if they can't run here.
 * Asset paths resolve against the configured backend origin so a frontend
 * node can load scramjet/bare-mux from the shared backend.
 * @returns {Promise<void>}
 */
function initProxy() {
	if (proxyReady) return proxyReady;

	proxyReady = (async () => {
		const problem = getContextProblem();
		if (problem) {
			throw Object.assign(new Error(problem.headline), problem);
		}

		// Wait for index.html-injected scram/baremux scripts (node + single-host).
		try {
			if (window.__GHOST_SCRIPTS_READY) {
				await Promise.race([
					window.__GHOST_SCRIPTS_READY,
					new Promise((_, rej) =>
						setTimeout(() => rej(new Error("timeout loading scram/baremux")), 15000)
					),
				]);
			}
		} catch (loadErr) {
			throw Object.assign(new Error("Scramjet failed to load."), {
				headline: "Scramjet failed to load.",
				detail: String(loadErr && loadErr.message ? loadErr.message : loadErr),
			});
		}
		for (let i = 0; i < 30; i++) {
			if (typeof $scramjetLoadController === "function" && typeof BareMux !== "undefined") {
				break;
			}
			await new Promise((r) => setTimeout(r, 100));
		}
		if (typeof $scramjetLoadController !== "function") {
			const backend = getBackendOrigin();
			throw Object.assign(new Error("Scramjet failed to load."), {
				headline: "Scramjet failed to load.",
				detail: isRemoteNode()
					? "Could not load scramjet from the backend origin (" +
						backend +
						"/scram/scramjet.all.js). Open that URL in a new tab — if it 404s, the backend is missing Scramjet assets. If it fails TLS, fix the certificate. Also confirm config.js backendOrigin has no trailing slash and is not the YOUR-BACKEND placeholder."
					: "scramjet.all.js did not load on this origin (" +
						location.origin +
						"/scram/scramjet.all.js).",
			});
		}

		const { ScramjetController } = $scramjetLoadController();
		const backend = getBackendOrigin();
		const scramPrefix = backend + "/scram";

		scramjet = new ScramjetController({
			files: {
				wasm: scramPrefix + "/scramjet.wasm.wasm",
				all: scramPrefix + "/scramjet.all.js",
				sync: scramPrefix + "/scramjet.sync.js",
			},
		});

		// Don't let a stuck init() freeze every click forever.
		await Promise.race([
			scramjet.init(),
			new Promise((resolve) => setTimeout(resolve, 8000)),
		]);

		// SharedWorker scripts MUST be same-origin. Always use the local
		// path. Remote frontend nodes ship their own copy of
		// baremux/worker.js; the backend public UI is already same-origin.
		//
		// Chromebooks often surface origin "null" / packed.local and reject:
		//   SecurityError: Failed to construct 'SharedWorker': Script at
		//   '...' cannot be accessed from origin 'null'.
		// Strategy:
		//   1) fetch worker → Blob → try SharedWorker(blob:)
		//   2) if that still throws, fall back to a dedicated Worker(blob:)
		//      + MessageChannel bridge (BareMuxConnection accepts a MessagePort).
		// worker.js was patched to support both onconnect (SharedWorker) and
		// self as the port (dedicated Worker).
		const baremuxWorkerPath = "/baremux/worker.js";
		let workerSrc = null;
		try {
			const resp = await fetch(baremuxWorkerPath, { cache: "force-cache" });
			if (!resp.ok) throw new Error("HTTP " + resp.status);
			workerSrc = await resp.text();
		} catch (fetchErr) {
			console.warn("[ghost] could not fetch baremux worker:", fetchErr);
		}
		const blobUrl = workerSrc
			? URL.createObjectURL(new Blob([workerSrc], { type: "text/javascript" }))
			: baremuxWorkerPath;

		function forceBareMuxPath() {
			try {
				localStorage.setItem("bare-mux-path", baremuxWorkerPath);
			} catch (err) {
				/* private mode / blocked storage */
			}
		}
		forceBareMuxPath();

		function bridgeToDedicated(worker) {
			const ch = new MessageChannel();
			ch.port1.onmessage = (ev) => {
				try {
					worker.postMessage(ev.data, ev.ports || []);
				} catch (err) {
					console.error("[ghost] bridge → dedicated worker:", err);
				}
			};
			return ch.port2;
		}

		let created = null;
		baremuxDedicatedWorker = null;
		baremuxUseRemoteTransport = false;

		try {
			created = new BareMux.BareMuxConnection(blobUrl);
			console.info("[ghost] bare-mux via SharedWorker");
		} catch (sharedErr) {
			console.warn(
				"[ghost] SharedWorker failed (will try dedicated Worker):",
				sharedErr && sharedErr.message ? sharedErr.message : sharedErr
			);
		}

		if (!created && typeof Worker !== "undefined" && workerSrc) {
			try {
				const dedi = new Worker(blobUrl);
				baremuxDedicatedWorker = dedi;
				dedi.onerror = (err) => {
					console.error("[ghost] dedicated baremux worker error:", err);
				};
				const pagePort = bridgeToDedicated(dedi);
				created = new BareMux.BareMuxConnection(pagePort);
				baremuxUseRemoteTransport = true;

				if (navigator.serviceWorker) {
					navigator.serviceWorker.addEventListener("message", (event) => {
						if (
							event.data &&
							event.data.type === "getPort" &&
							event.data.port &&
							baremuxDedicatedWorker
						) {
							console.debug("[ghost] answering SW getPort with dedicated bridge");
							const swPort = bridgeToDedicated(baremuxDedicatedWorker);
							try {
								event.data.port.postMessage(swPort, [swPort]);
							} catch (err) {
								console.error("[ghost] getPort reply failed:", err);
							}
						}
					});
				}

				console.info(
					"[ghost] bare-mux via dedicated Worker (Chromebook fallback, remote transport)"
				);
			} catch (dediErr) {
				console.error("[ghost] dedicated Worker fallback also failed:", dediErr);
			}
		}

		if (!created) {
			created = new BareMux.BareMuxConnection(baremuxWorkerPath);
		}
		forceBareMuxPath();
		connection = created;
	})();

	// Allow a retry after a failure instead of caching the rejection.
	proxyReady.catch(() => {
		proxyReady = null;
	});

	return proxyReady;
}

// If this tab already had an older service worker controlling it (e.g.
// from before a deploy) and a newer one takes over, the tab keeps running
// whatever it already loaded into memory until a full reload. Do that
// reload automatically, once, so nobody has to know to hard-refresh or
// clear site data to get unstuck.
//
// This must NOT fire when the page is claimed by a worker for the very
// first time (no controller -> a controller): clients.claim() in sw.js makes
// that happen to every first-time visitor, and reloading at that moment
// would throw away whatever they just clicked.
if (navigator.serviceWorker) {
	const hadControllerAlready = !!navigator.serviceWorker.controller;
	let sjReloadedForNewSW = false;
	navigator.serviceWorker.addEventListener("controllerchange", () => {
		if (!hadControllerAlready || sjReloadedForNewSW) return;
		sjReloadedForNewSW = true;
		// Prefer replace to "/" over reload so a filter that has marked this
		// tab (e.g. Securly tabsBeingBlocked) is less likely to intercept a
		// "new" main_frame navigation to a non-root path.
		try {
			location.replace("/");
		} catch (err) {
			location.reload();
		}
	});
}

/** The live scramjet frame, once one has been created. */
let frame = null;

/* ----------------------------------------------------------------- *
 * Default search engine
 * ----------------------------------------------------------------- */

const ENGINE_STORAGE_KEY = "sj-default-engine";

function loadSavedEngine() {
	try {
		const saved = localStorage.getItem(ENGINE_STORAGE_KEY);
		if (saved) {
			const match = Array.from(engineSelect.options).find(
				(opt) => opt.value === saved
			);
			if (match) {
				engineSelect.value = saved;
			}
		}
	} catch (err) {
		// localStorage unavailable (private mode, etc) - fall back to default
	}
	searchEngine.value = engineSelect.value;
}

engineSelect.addEventListener("change", () => {
	searchEngine.value = engineSelect.value;
	try {
		localStorage.setItem(ENGINE_STORAGE_KEY, engineSelect.value);
	} catch (err) {
		// ignore
	}
});

loadSavedEngine();

/* ----------------------------------------------------------------- *
 * Navigation helpers
 * ----------------------------------------------------------------- */

/**
 * Makes sure the proxy is ready and the bare-mux transport is configured,
 * then creates (or reuses) the scramjet frame and navigates it to the
 * address typed in (a URL, a domain/IP, or a search query).
 * @param {string} rawInput
 * @param {string} [engineTemplate]
 */
async function navigate(rawInput, engineTemplate) {
	const input = (rawInput || "").trim();
	if (!input) return;

	clearError();

	try {
		await initProxy();
	} catch (err) {
		reportError(err, "Failed to start the proxy.");
		return;
	}

	try {
		await registerSW();
	} catch (err) {
		reportError(err, "Failed to register service worker.");
		return;
	}

	const url = search(input, engineTemplate || searchEngine.value);

	// Wisp lives on the backend. In single-host mode that is this origin;
	// on a frontend node it is the configured backendOrigin so all proxy
	// tunnels share one backend regardless of which UI host the user opened.
	const backend = getBackendOrigin();
	let backendHost;
	let backendProto;
	try {
		const u = new URL(backend);
		backendHost = u.host;
		backendProto = u.protocol;
	} catch (err) {
		backendHost = location.host;
		backendProto = location.protocol;
	}
	const wispUrl =
		(backendProto === "https:" ? "wss" : "ws") + "://" + backendHost + "/wisp/";

	// libcurl transport module also lives on the backend.
	const libcurlPath = backend + "/libcurl/index.mjs";

	try {
		if (baremuxUseRemoteTransport) {
			const current = await connection.getTransport().catch(() => "");
			if (current !== libcurlPath && current !== `bare-mux-remote (${libcurlPath})`) {
				const mod = await import(/* webpackIgnore: true */ libcurlPath);
				const Transport = mod.default;
				const transport = new Transport({ websocket: wispUrl });
				if (typeof transport.init === "function") {
					await transport.init();
				}
				await connection.setRemoteTransport(transport, libcurlPath);
				console.info("[ghost] setRemoteTransport(libcurl) ok");
			}
		} else if ((await connection.getTransport()) !== libcurlPath) {
			await connection.setTransport(libcurlPath, [{ websocket: wispUrl }]);
		}
	} catch (err) {
		reportError(err, "Failed to set up the connection to the server.");
		return;
	}

	showBrowseView();

	if (!frame) {
		frame = scramjet.createFrame();
		frame.frame.id = "sj-frame";
		browseView.appendChild(frame.frame);

		// Keep the navbar's address box in step with link clicks and
		// redirects inside the proxied page, not just with what was typed.
		try {
			frame.addEventListener("urlchange", (event) => {
				if (event && event.url) {
					const u = String(event.url);
					syncOmnibarUrl(u);
					if (typeof rememberProxiedUrl === "function") rememberProxiedUrl(u);
				}
			});
		} catch (err) {
			// older scramjet builds: the box just shows the last typed URL
		}
	}

	if (typeof rememberProxiedUrl === "function") rememberProxiedUrl(url);
	frame.go(url);
	syncOmnibarUrl(url);
}

form.addEventListener("submit", async (event) => {
	event.preventDefault();
	await navigate(address.value, searchEngine.value);
});

/* ----------------------------------------------------------------- *
 * Quick links
 * ----------------------------------------------------------------- */

document.querySelectorAll(".quick-link").forEach((btn) => {
	btn.addEventListener("click", async () => {
		const url = btn.getAttribute("data-url");
		if (url) await navigate(url, searchEngine.value);
	});
});

/* ----------------------------------------------------------------- *
 * Home <-> browse view transition (with the open/close animation)
 * ----------------------------------------------------------------- */

let leaveTimer = null;
let homeTimer = null;

function showBrowseView() {
	document.body.classList.add("browsing");
	clearTimeout(homeTimer);

	// The browse view fades in over the home screen while the home content
	// plays its fade-up animation in reverse.
	browseView.hidden = false;
	requestAnimationFrame(() => browseView.classList.add("show"));

	if (homeView.hidden) return;
	homeView.classList.add("sj-leaving");
	clearTimeout(leaveTimer);
	leaveTimer = setTimeout(() => {
		homeView.hidden = true;
		homeView.classList.remove("sj-leaving");
	}, 520);

	// One-page lock: keep top-level URL stable while browsing.
	if (typeof startUrlLock === "function") startUrlLock();
}

function showHomeView() {
	document.body.classList.remove("browsing");
	clearTimeout(leaveTimer);

	// Un-hiding the home view replays its entrance animation.
	homeView.classList.remove("sj-leaving");
	homeView.hidden = false;
	browseView.classList.remove("show");

	// Once the browse view has faded out, tear the page down so nothing keeps
	// running (audio/video) behind the home screen.
	clearTimeout(homeTimer);
	homeTimer = setTimeout(() => {
		if (browseView.classList.contains("show")) return;
		browseView.hidden = true;
		if (frame) {
			frame.frame.remove();
			frame = null;
		}
		syncOmnibarUrl("");
	}, 400);

	if (typeof stopUrlLock === "function") stopUrlLock();
	if (typeof lockTopLevelUrl === "function") lockTopLevelUrl();
}

/* ----------------------------------------------------------------- *
 * Bottom navbar / omnibar
 * ----------------------------------------------------------------- */

const navbar = document.getElementById("sj-navbar");
const navbarHandle = document.getElementById("sj-navbar-handle");
const omnibarForm = document.getElementById("sj-omnibar-form");
const omnibarUrl = document.getElementById("sj-omnibar-url");
const navBack = document.getElementById("sj-nav-back");
const navForward = document.getElementById("sj-nav-forward");
const navReload = document.getElementById("sj-nav-reload");
const navHome = document.getElementById("sj-nav-home");

function openNavbar() {
	navbar.classList.remove("closing");
	navbar.classList.add("open");
	navbarHandle.setAttribute("aria-expanded", "true");
	omnibarUrl.focus();
}

function closeNavbar() {
	if (!navbar.classList.contains("open")) return;
	navbar.classList.add("closing");
	navbar.classList.remove("open");
	navbarHandle.setAttribute("aria-expanded", "false");
	setTimeout(() => navbar.classList.remove("closing"), 320);
}

navbarHandle.addEventListener("click", () => {
	if (navbar.classList.contains("open")) closeNavbar();
	else openNavbar();
});

document.addEventListener("click", (event) => {
	if (!navbar.classList.contains("open")) return;
	if (navbar.contains(event.target)) return;
	closeNavbar();
});

// Clicks inside the proxied page never reach this document, but they do move
// focus into the iframe - treat that as a click outside the navbar too.
window.addEventListener("blur", () => {
	setTimeout(() => {
		if (frame && document.activeElement === frame.frame) closeNavbar();
	}, 0);
});

function syncOmnibarUrl(url) {
	try {
		omnibarUrl.value = url;
	} catch (err) {
		// ignore
	}
}

omnibarForm.addEventListener("submit", async (event) => {
	event.preventDefault();
	if (!omnibarUrl.value.trim()) return;
	await navigate(omnibarUrl.value, searchEngine.value);
	closeNavbar();
});

/**
 * Runs `action` against the proxied page's window, ignoring a page that
 * isn't loaded yet or isn't reachable.
 * @param {(win: Window) => void} action
 */
function withFrameWindow(action) {
	if (!frame || !frame.frame || !frame.frame.contentWindow) return;
	try {
		action(frame.frame.contentWindow);
	} catch (err) {
		// cross-origin or not ready yet
	}
}

navBack.addEventListener("click", () => {
	withFrameWindow((win) => win.history.back());
});

navForward.addEventListener("click", () => {
	withFrameWindow((win) => win.history.forward());
});

navReload.addEventListener("click", () => {
	withFrameWindow((win) => win.location.reload());
});

/* ----------------------------------------------------------------- *
 * Home button (with "are you sure?" confirmation)
 * ----------------------------------------------------------------- */

const homeConfirm = document.getElementById("sj-home-confirm");
const homeConfirmYes = document.getElementById("sj-home-confirm-yes");
const homeConfirmNo = document.getElementById("sj-home-confirm-no");

function askToGoHome() {
	// Only ask for confirmation if we're actually browsing somewhere.
	if (browseView.hidden) return;
	homeConfirm.hidden = false;
	homeConfirmNo.focus();
}

function hideHomeConfirm() {
	homeConfirm.hidden = true;
}

navHome.addEventListener("click", () => {
	closeNavbar();
	askToGoHome();
});

homeConfirmYes.addEventListener("click", () => {
	hideHomeConfirm();
	closeNavbar();
	showHomeView();
});

homeConfirmNo.addEventListener("click", hideHomeConfirm);

homeConfirm.addEventListener("click", (event) => {
	if (event.target === homeConfirm) hideHomeConfirm();
});

document.addEventListener("keydown", (event) => {
	if (event.key !== "Escape") return;
	if (!homeConfirm.hidden) hideHomeConfirm();
	else closeNavbar();
});

/* ----------------------------------------------------------------- *
 * Theme toggle (home screen corner + inside the navbar while browsing)
 * ----------------------------------------------------------------- */

// theme.js (loaded in <head>) owns the saved/system theme logic; fall back
// to plain dark if it somehow failed to load.
const sjTheme = window.__sjTheme || {
	STORAGE_KEY: "sj-theme",
	resolveTheme: () => "dark",
	getStoredTheme: () => null,
};

function applyTheme(theme) {
	document.documentElement.setAttribute("data-theme", theme);
}

function toggleTheme() {
	const current =
		document.documentElement.getAttribute("data-theme") === "light"
			? "light"
			: "dark";
	const next = current === "light" ? "dark" : "light";
	applyTheme(next);
	try {
		localStorage.setItem(sjTheme.STORAGE_KEY, next);
	} catch (err) {
		// ignore
	}
}

document.querySelectorAll(".js-theme-toggle").forEach((btn) => {
	btn.addEventListener("click", toggleTheme);
});

// If the user hasn't explicitly picked a theme, keep following the system
// theme live (and keep defaulting to dark if the system preference can't
// be detected at all).
try {
	if (window.matchMedia) {
		const lightQuery = window.matchMedia("(prefers-color-scheme: light)");
		const onSchemeChange = () => {
			if (sjTheme.getStoredTheme()) return; // explicit choice wins
			applyTheme(sjTheme.resolveTheme());
		};
		if (lightQuery.addEventListener) {
			lightQuery.addEventListener("change", onSchemeChange);
		} else if (lightQuery.addListener) {
			lightQuery.addListener(onSchemeChange);
		}
	}
} catch (err) {
	// ignore - theme just won't live-update with the system
}

/* ----------------------------------------------------------------- *
 * Shadow first-load screen (5s black + spinner, then fade & start proxy)
 * ----------------------------------------------------------------- */

const shadowLoader = document.getElementById("sj-shadow-loader");
const SHADOW_MIN_MS = 5000;

function runAfterShadow(fn) {
	if (!shadowLoader) {
		fn();
		return;
	}
	document.body.classList.add("shadow-active");
	const start = Date.now();
	const remaining = Math.max(0, SHADOW_MIN_MS - (Date.now() - start));
	setTimeout(() => {
		shadowLoader.classList.add("shadow-fade-out");
		setTimeout(() => {
			shadowLoader.classList.add("shadow-gone");
			document.body.classList.remove("shadow-active");
			fn();
		}, 560);
	}, remaining);
}

/* ----------------------------------------------------------------- *
 * Tab title / favicon switch when the tab is hidden (CK - Home)
 * ----------------------------------------------------------------- */

const ORIGINAL_TITLE = document.title || "Ghost";
const FAVICON_NORMAL = "favicon.ico";
const FAVICON_ALT = "faviconalt.ico";
const HIDDEN_TITLE = "CK - Home";

function setFavicon(href) {
	const links = [
		document.getElementById("sj-favicon"),
		document.getElementById("sj-favicon-shortcut"),
	];
	for (const link of links) {
		if (!link) continue;
		// Force a reload of the icon by briefly changing href.
		link.href = href + "?t=" + Date.now();
		link.href = href;
	}
	// Also update any other rel=icon the browser may have cached.
	document.querySelectorAll('link[rel="icon"], link[rel="shortcut icon"]').forEach((el) => {
		if (el.id === "sj-favicon" || el.id === "sj-favicon-shortcut") return;
		el.href = href;
	});
}

function onVisibilityChange() {
	if (document.hidden || document.visibilityState === "hidden") {
		document.title = HIDDEN_TITLE;
		setFavicon(FAVICON_ALT);
	} else {
		document.title = ORIGINAL_TITLE;
		setFavicon(FAVICON_NORMAL);
	}
}

document.addEventListener("visibilitychange", onVisibilityChange);

/* ----------------------------------------------------------------- *
 * Filter / Securly resistance
 *
 * Securly for Chromebooks (see uploaded extension):
 *  - Marks a tab in tabsBeingBlocked then either redirects the next
 *    main_frame request or calls chrome.tabs.update() to blocked.html.
 *  - Can also redirect sub_frame requests when checkiFrames is enabled.
 *  - Injects a "well-path-widget" overlay via content4.min.js on the
 *    top frame (all_frames: false).
 *
 * When the user cancels the browser "leave site?" dialog that our
 * beforeunload creates, the tab stays on Ghost but Securly may still
 * have injected nodes or replaced the iframe with its block page while
 * our navbar / home chrome remain visible. The code below:
 *  1. Keeps a permanent beforeunload so top-level redirects are gated.
 *  2. Freezes the top-level URL on "/" so the tab never looks like a
 *     new navigation to the filter.
 *  3. Strips known Securly overlays from the top document.
 *  4. Detects when the proxied iframe has been turned into Securly's
 *     blocked.html and recovers (reload frame / soft message).
 *  5. Avoids unnecessary full reloads that would re-trigger a blocked
 *     main_frame hit after the tab has been marked.
 * ----------------------------------------------------------------- */

const SECURLY_BLOCK_MARKERS = [
	"Looks like this page isn't allowed",
	"goes against your school's online rules",
	"well-path-widget",
	"blocked-message",
	"Blockedbg_full",
];

const SECURLY_NODE_SELECTORS = [
	".well-path-widget-wrapper",
	".well-path-widget",
	".bg-img",
	".blocked-message",
	".blocked-logo",
];

function looksLikeSecurlyBlockDoc(doc) {
	if (!doc || !doc.documentElement) return false;
	try {
		const html = doc.documentElement.innerHTML || "";
		if (!html) return false;
		for (const marker of SECURLY_BLOCK_MARKERS) {
			if (html.indexOf(marker) !== -1) return true;
		}
		// Extension-served blocked page often keeps a chrome-extension URL.
		const loc = String(doc.location && doc.location.href || "");
		if (loc.indexOf("chrome-extension://") === 0 && loc.indexOf("blocked") !== -1) {
			return true;
		}
	} catch (err) {
		// cross-origin iframe we can't read – not Securly's same-origin block page
	}
	return false;
}

function stripSecurlyFromTopDocument() {
	try {
		for (const sel of SECURLY_NODE_SELECTORS) {
			document.querySelectorAll(sel).forEach((el) => {
				try {
					el.remove();
				} catch (err) {
					/* ignore */
				}
			});
		}
		// Catch any leftover full-page overlays that quote Securly copy.
		const walk = document.body ? document.body.querySelectorAll("div, section, aside") : [];
		for (const el of walk) {
			const text = (el.textContent || "").slice(0, 400);
			if (
				text.indexOf("Looks like this page isn't allowed") !== -1 ||
				text.indexOf("school's online rules") !== -1
			) {
				// Don't remove our own UI roots.
				if (el.id === "sj-home" || el.id === "sj-browse-view" || el.id === "sj-navbar") {
					continue;
				}
				if (el.closest && (el.closest("#sj-home") || el.closest("#sj-browse-view") || el.closest("#sj-navbar"))) {
					continue;
				}
				try {
					el.remove();
				} catch (err) {
					/* ignore */
				}
			}
		}
	} catch (err) {
		/* ignore */
	}
}

/**
 * If Securly redirected the proxied iframe to its block page, the outer
 * Ghost chrome stays visible ("elements for browsing are still on screen").
 * Detect that and recover by reloading the last known URL into the frame,
 * or falling back to the home view with a toast.
 */
let lastProxiedUrl = "";
let iframeWatchTimer = null;

function rememberProxiedUrl(url) {
	if (url) lastProxiedUrl = String(url);
}

function recoverIframeFromFilter() {
	if (!frame || !frame.frame) return false;
	let blocked = false;
	try {
		const doc = frame.frame.contentDocument;
		blocked = looksLikeSecurlyBlockDoc(doc);
	} catch (err) {
		// Can't read – may still be our proxy origin; leave alone.
		blocked = false;
	}
	if (!blocked) {
		// Also treat a chrome-extension iframe src as a hijack.
		try {
			const src = frame.frame.getAttribute("src") || "";
			if (src.indexOf("chrome-extension://") === 0) blocked = true;
		} catch (err) {
			/* ignore */
		}
	}
	if (!blocked) return false;

	console.warn("[ghost] Proxied frame was replaced by a filter block page – recovering.");
	showProblem(
		"A web filter tried to block this page inside the viewer.",
		"Ghost kept the session on this tab. Retrying the last address…"
	);

	if (lastProxiedUrl) {
		try {
			frame.go(lastProxiedUrl);
			return true;
		} catch (err) {
			/* fall through */
		}
	}
	// Last resort: tear down the compromised frame and return home.
	try {
		frame.frame.remove();
	} catch (err) {
		/* ignore */
	}
	frame = null;
	showHomeView();
	return true;
}

function startIframeWatch() {
	stopIframeWatch();
	iframeWatchTimer = setInterval(() => {
		if (!document.body.classList.contains("browsing")) return;
		stripSecurlyFromTopDocument();
		recoverIframeFromFilter();
	}, 1200);
}

function stopIframeWatch() {
	if (iframeWatchTimer) {
		clearInterval(iframeWatchTimer);
		iframeWatchTimer = null;
	}
}

// Continuous top-document observer for Securly's well-path widget / overlays.
try {
	const topObserver = new MutationObserver(() => {
		stripSecurlyFromTopDocument();
	});
	if (document.documentElement) {
		topObserver.observe(document.documentElement, {
			childList: true,
			subtree: true,
		});
	}
} catch (err) {
	/* MutationObserver unavailable */
}

/* Always-on leave confirmation – blocks chrome.tabs.update redirects when the
 * user cancels. This is intentional for the Ghost tab itself. */
window.addEventListener("beforeunload", (event) => {
	event.preventDefault();
	event.returnValue = "";
	return "";
});

/* ----------------------------------------------------------------- *
 * One-page / SPA hardening (stable top-level URL)
 * ----------------------------------------------------------------- */

function lockTopLevelUrl() {
	try {
		const path = location.pathname + location.search + location.hash;
		if (path !== "/" && path !== "/index.html" && !path.startsWith("/?")) {
			history.replaceState(null, "", "/");
		}
	} catch (err) {
		/* ignore */
	}
}

window.addEventListener("popstate", () => {
	lockTopLevelUrl();
});

// Freeze history so pushState/replaceState from scripts or extensions
// can't leave a non-root entry that filters treat as a new page.
try {
	const _push = history.pushState.bind(history);
	const _replace = history.replaceState.bind(history);
	history.pushState = function (state, title, url) {
		if (url != null && String(url) !== "" && String(url) !== "/" && !String(url).startsWith("/#") && !String(url).startsWith("?")) {
			return _replace(state, title, "/");
		}
		return _push(state, title, url);
	};
	history.replaceState = function (state, title, url) {
		if (url != null && String(url) !== "" && String(url) !== "/" && !String(url).startsWith("/#") && !String(url).startsWith("?")) {
			return _replace(state, title, "/");
		}
		return _replace(state, title, url);
	};
} catch (err) {
	/* ignore */
}

let urlLockTimer = null;
function startUrlLock() {
	lockTopLevelUrl();
	clearInterval(urlLockTimer);
	// Gentle interval – aggressive replaceState can itself look like navigation.
	urlLockTimer = setInterval(lockTopLevelUrl, 5000);
	startIframeWatch();
}
function stopUrlLock() {
	clearInterval(urlLockTimer);
	urlLockTimer = null;
	stopIframeWatch();
}

/* ----------------------------------------------------------------- *
 * Soft-recover if the entire body was replaced without a full unload
 * (some filters swap documentElement content in place).
 * ----------------------------------------------------------------- */

const GHOST_ROOT_IDS = ["sj-home", "sj-browse-view", "sj-navbar", "sj-shadow-loader"];

function ghostDomIntact() {
	return GHOST_ROOT_IDS.every((id) => document.getElementById(id));
}

setInterval(() => {
	if (!ghostDomIntact()) {
		// Hard recovery: only safe option is a same-origin reload of Ghost.
		// Prefer not to do this if Securly has marked the tab, but without
		// our DOM we can't continue anyway.
		console.warn("[ghost] Core UI nodes missing – reloading Ghost.");
		try {
			location.replace("/");
		} catch (err) {
			location.href = "/";
		}
	} else {
		stripSecurlyFromTopDocument();
	}
}, 2000);

/* ----------------------------------------------------------------- *
 * Start up (after shadow delay)
 * ----------------------------------------------------------------- */

runAfterShadow(() => {
	requestAnimationFrame(() => {
		homeView.classList.add("sj-anim-ready");
	});

	initProxy().then(
		() =>
			registerSW().catch((err) =>
				reportError(err, "Failed to register service worker.")
			),
		(err) => reportError(err, "Failed to start the proxy.")
	);
});
