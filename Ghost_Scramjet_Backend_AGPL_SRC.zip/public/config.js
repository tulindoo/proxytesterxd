/**
 * Ghost runtime configuration.
 *
 * Single-host mode (default): leave backendOrigin empty. The page talks to
 * its own origin for /wisp/, /scram/, /baremux/, /libcurl/.
 *
 * Frontend-node mode: set backendOrigin to the full origin of the Ghost
 * backend (e.g. "https://ghost-backend.example.com"). This static UI can
 * then be hosted on any other HTTPS host/CDN while all proxy traffic goes
 * through that backend. No trailing slash.
 */
window.__GHOST_CONFIG = {
	backendOrigin: "",
	// Optional display name override for the tab title on this node.
	siteTitle: "",
};
