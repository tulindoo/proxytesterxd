/**
 * Service-worker-side config. Must stay in sync with config.js backendOrigin
 * when this frontend is deployed as a remote node.
 * Leave empty for single-host mode.
 */
self.__GHOST_BACKEND = "";
