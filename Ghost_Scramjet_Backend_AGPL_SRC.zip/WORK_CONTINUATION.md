placeholder guard + script onload; node points to howtocookchicken:24455
